export { default as Toggle } from "./Toggle";
export type { ToggleProps, Scales as ToggleScales } from "./types";
